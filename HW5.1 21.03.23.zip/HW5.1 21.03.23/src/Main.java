public class Main {

    // 1 уровень сложности: Можно сделать оба задания в одном проекте.
    //1 Напишите метод, который принимает три строки и строку-разделитель.
    // Метод возвращает единую строку, состоящую из исходных строк,
    // разделённых строкой-разделителем. Например, на входе "один", "два", "три", "|". На выходе: "один|два|три"
    //2 Напишите метод, который выводит в консоль первый символ переданной в него строки.

    public static void main(String[] args) {
    String ab = concat("dancing" ,"wiht the" , "eyes closed" ,"|");
        System.out.println(ab);


        String gg = String.valueOf(getFirstSymbol("Asus"));
        System.out.println(gg);

        String bb1 = "Yor";
        getFirstSymbol2(bb1);


    }

    public static String  concat(String a ,String b, String c , String d ){
        return (a + d + b + d + c);



    }

    public static char getFirstSymbol(String u){
        return (u.charAt(0));


    }

    public static void getFirstSymbol2(String j){
        System.out.println(j.charAt(0));

    }


}