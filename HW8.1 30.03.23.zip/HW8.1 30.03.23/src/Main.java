import java.util.Scanner;

public class Main {
    //1 уровень сложности: Пользователь вводит, сколько лет он состоит в браке.
    // Программа должна вывести, какая годовщина свадьбы будет у пользователя следующей
    // (бумажная, ситцевая, чугунная, серебряная и.д.). Не обязательно указывать все годовщины,
    // достаточно 10-15. Узнать про годовщины можно, например,
    // здесь https://instalook.ru/blog/nazvaniya-vseh-godovschin-svadeb-do-100-let
    public static void main(String[] args) {

     Scanner scn = new Scanner(System.in);
        System.out.println("Сколько лет состоите в браке");
     int nextTitle = scn.nextInt() +1;
        System.out.println("Следующая годовщина:");
     String message = switch (nextTitle){

         case 1 -> getNextName(Anniversaries.ZITZEVAYA);
         case 2 -> getNextName(Anniversaries.BUMAJNAYA);
         case 3 -> getNextName(Anniversaries.KOJANAYA);
         case 4 -> getNextName(Anniversaries.LYANAYA);
         case 5 -> getNextName(Anniversaries.DEREVYANNA);
         case 6 -> getNextName(Anniversaries.CHUGUNNAYA);
         case 7 -> getNextName(Anniversaries.MEDNAYA);
         case 8 -> getNextName(Anniversaries.JESTYANA);
         case 9 -> getNextName(Anniversaries.FAYANSOVAYA);
         case 10 -> getNextName(Anniversaries.OLOVYANNA);
         default -> "Введен слишком много";

     };
        System.out.println(message);

    }
    private static String getNextName(Anniversaries next){
        return next.name();

    }
}