public enum Anniversaries {
    ZITZEVAYA,
    BUMAJNAYA,
    KOJANAYA,
    LYANAYA,
    DEREVYANNA,
    CHUGUNNAYA,
    MEDNAYA,
    JESTYANA,
    FAYANSOVAYA,
    OLOVYANNA
}
