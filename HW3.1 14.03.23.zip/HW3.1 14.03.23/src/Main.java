import java.util.Scanner;

public class Main {
    //1 Пользователь вводит трёхзначное число.
    //2 Программа должна вывести на экран все цифры этого числа. Какждая цифра должна быть выведена в отдельной строчке.
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.print("введите трёхзначное чилсо:");

        int scr1 = scr.nextInt();

        System.out.println(scr1/100);
        System.out.println(scr1/10%10 );
        System.out.println(scr1%10);



    }
}