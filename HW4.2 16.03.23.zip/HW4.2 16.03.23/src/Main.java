public class Main {
    //1 Создайте переменную long lo = 1000L;
    //2 Присвойте её значение новым переменным типов byte, short, int, double.
    //3 Выведите значение новых переменных в консоль.
    public static void main(String[] args) {
        long lo = 1000l;
        byte a = (byte) lo;
        short b = (short) a;
        int c = b;
        double d = c;
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);
    }
}