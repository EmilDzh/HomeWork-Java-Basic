import java.util.Random;

public class Main {
    //Проект 2
    //Компьютер генерирует три произвольных числа из диапазона от 0 до 999.
    //Найдите сумму чисел, выведите на экран.
    //Найдите произведение чисел, выведите на экран.
    public static void main(String[] args) {
        Random r = new Random();

        int r1 = r.nextInt(999);
        int r2 = r.nextInt(999);
        int r3 = r.nextInt(999);
        System.out.println(r1);
        System.out.println(r2);
        System.out.println(r3);

        System.out.println("сумма чисел");

        System.out.println(r1+r2+r3);

        System.out.println("произведение чисел");
        System.out.println(r1 * r2 * r3);

    }
}