import java.util.Scanner;

public class Main {

    //3 Пользователь вводит два числа.
    // Если они не равны, то вывести в консоль их сумму,
    // иначе вывести их произведение. Используйте тернарный оператор.
    public static void main(String[] args) {

        Scanner scn = new Scanner(System.in);
        int a = scn.nextInt();
        int b = scn.nextInt();

        int c = a != b ? a+b : a*b ;
        System.out.println(c);

    }
}