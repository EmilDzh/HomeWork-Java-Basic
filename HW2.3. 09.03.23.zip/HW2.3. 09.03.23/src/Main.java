public class Main {
    public static void main(String[] args) {
        System.out.println( 5 % 4 );
        System.out.println( 15 % 3 );
       int summe = 1;
       int summe1 = 0;
        System.out.println();
        int num = 2 % 2 ;
        int num1 = 7 % 2 ;
        int num2 = 13 % 2 ;
        int num3 = 14 % 2 ;
        System.out.println( num );
        // num = 0;
        System.out.println( num1 );
        // num1 = 1;
        System.out.println( num2 );
        // num2 = 1;
        System.out.println( num3 );
        // num3 = 0;
        System.out.println();
        int z = 123654;
        System.out.println( z % 2 );
    }
}