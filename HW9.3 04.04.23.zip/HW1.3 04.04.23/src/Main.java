import java.time.Month;
import java.util.Scanner;

public class Main {
    //Проект 3.
    //Используйте foreach.
    //Дан Enum месяцев. Пользователь вводит имя текущего месяца в консоль.
    // Программа должна вывести все месяцы, кроме того, что ввёл пользователь.
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите названия месяца");
        String str = scn.nextLine();
        Month yep = Month.valueOf(str);

        for (Month name : Month.values()) {
            if (yep != name)
                System.out.println("Ост месяцы" + ":" + name);

        }


    }
}