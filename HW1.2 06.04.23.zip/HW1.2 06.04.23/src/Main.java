import java.util.Arrays;
import java.util.Random;

public class Main {
    //TODO указал в рандоме диапозон чтоб было понятней).
    //2 Создайте случайно заполненный числовой массив, выведите его в консоль.
    // Найдите максимальное по модулю число в массиве и выведите его в консоль.
    public static void main(String[] args) {
        Random rnd = new Random();
        int random = rnd.nextInt(0, 20);
        int[] randomArray = new int[random];
        int max = randomArray[0];

        for (int i = 0; i < randomArray.length; i++) {
            int number = rnd.nextInt(0, 20);
            randomArray[i] = number;
            if (randomArray[i] > max)
                max = randomArray[i];


        }

        System.out.println("Длина строки :" + randomArray.length);
        System.out.println(Arrays.toString(randomArray));
        System.out.println("Максимальное число в Массиве :" + max);
    }
}