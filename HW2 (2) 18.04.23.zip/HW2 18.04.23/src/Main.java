import java.util.Arrays;
import java.util.Random;

public class Main {
    //Проект 2. Практика алгоритмов
    //На выбор: либо реализовать любую из сортировок самостоятельно, либо решить задание ниже.
    //Задание из собеседования Яндекс: дана строка вида AAABBBCCCDDEG…,
    // состоящая только из заглавных символов латинского алфавита.
    // Напишите метод, который «свернёт» строку к виду A4B3C3D2EG,
    // т.е. количество букв записывается цифрой. Если буква одна, то цифра не ставится.
    public static void main(String[] args) {
        Random rnd = new Random();
        int[] array = new int[10];

        for (int i = 0; i < array.length; i++) {
            array[i] = rnd.nextInt(1, 50);

        }
        System.out.println(Arrays.toString(array) + " " + "До");
        bubbleSort(array);
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " " );

        }
        System.out.println();

        String str = "AAABBBCCCDDEG";
        StringBuilder result = new StringBuilder();
        char prevChar = str.charAt(0);
        int count = 1;

        for (int i = 1; i < str.length(); i++) {
            char currentChar = str.charAt(i);

            if (prevChar == currentChar) {
                count++;
            } else {
                result.append(prevChar);
                if (count > 1) {
                    result.append(count);
                }
                count = 1;
                prevChar = currentChar;
            }

        }
        result.append(prevChar);
        if (count > 1) {
            result.append(count);
        }
        System.out.println(result);
    }

    private static void bubbleSort(int[] array) {
        int length = array.length;

        for (int i = 0; i < length-1; i++) {
            for (int j = 1; j < length - i; j++) {
                if (array[j] < array[j - 1]) {
                    int temp = array[j];
                    array[j] = array[j-1];
                    array[j-1] = temp;

                }

            }

        }

    }


}