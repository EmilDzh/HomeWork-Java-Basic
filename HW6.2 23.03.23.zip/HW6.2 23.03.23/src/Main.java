import java.util.Scanner;

public class Main {

    //2 Пользователь вводит строку. Если строка начинается с цифры (0, 1, 2, 3, 4, 5, 6 , 7, 8, 9),
    // то вывести эту цифру в консоль. Если строка начинается со знака _ или знака -,
    // то вывести в консоль строку без этого знака. Используйте методы startsWith, charAt и substring.
    public static void main(String[] args) {

        Scanner scn = new Scanner(System.in);
        System.out.println("Введите строку");
        String str = scn.nextLine();

      if ( str.startsWith("0") ){
          System.out.println(str.charAt(0));
      }if ( str.startsWith("1") ){
            System.out.println(str.charAt(0));
        }if ( str.startsWith("2") ){
            System.out.println(str.charAt(0));
        }if ( str.startsWith("3") ){
            System.out.println(str.charAt(0));
        }if ( str.startsWith("4") ){
            System.out.println(str.charAt(0));
        }if ( str.startsWith("5") ){
            System.out.println(str.charAt(0));
        }if ( str.startsWith("6") ){
            System.out.println(str.charAt(0));
        }if ( str.startsWith("7") ){
            System.out.println(str.charAt(0));
        }if ( str.startsWith("8") ){
            System.out.println(str.charAt(0));
        }if ( str.startsWith("9") ){
            System.out.println(str.charAt(0));
        }

         if(str.startsWith("-")){
             System.out.println(str.substring(1));

         } if(str.startsWith("_")){
            System.out.println(str.substring(1));

        }





    }

    }
