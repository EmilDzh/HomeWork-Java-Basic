import java.util.Arrays;
import java.util.Scanner;

public class Main {
    //4 Пользователь вводит строку. Посчитайте количество слов в строке и выведите в консоль.
    // Разделителем между словами считать только пробел.
    // Если в строке есть слова, которые длиннее трёх символов, то вывести эти слова в консоль.
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        String str = scn.nextLine();
        String[] strArray = str.split(" ");
        System.out.println(Arrays.toString(strArray));
        System.out.println("количество слов :" +strArray.length);
        String a = "asa";

        for (int i = 0; i < strArray.length; i++) {
            if(strArray[0].length() >= a.length())
                System.out.println(strArray[0]);
            if(strArray[0].length() > strArray.length)
                break;
            if(strArray[1].length() >= a.length())
                System.out.println(strArray[1]);
            if(strArray[1].length() > strArray.length)
                break;
            if(strArray[2].length() >= a.length())
                System.out.println(strArray[2]);
            if(strArray[2].length() > strArray.length)
                break;
            if(strArray[3].length() >= a.length())
                System.out.println(strArray[3]);
            if(strArray[3].length() >= strArray.length)
                break;
            if(strArray[4].length() >= a.length())
                System.out.println(strArray[4]);
            if(strArray[4].length() >= strArray.length)
                break;
            if(strArray[5].length() >= a.length())
                System.out.println(strArray[5]);
            if(strArray[5].length() >= strArray.length)
                break;
        }



    }


}
























