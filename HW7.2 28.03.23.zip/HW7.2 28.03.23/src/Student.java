public class Student {
    private String name;
    private String group;

    public Student(String name) {
        this.name = name;
    }

    public Student(String name, String group) {
        this(name);
        this.group = group;
    }
    public Student(Student student) {
        this.name = student.name;
        this.group = student.group;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }
}

