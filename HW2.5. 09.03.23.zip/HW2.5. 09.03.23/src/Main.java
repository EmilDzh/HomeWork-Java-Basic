public class Main {
    public static void main(String[] args) {

        byte ace = 127;
        System.out.println(ace);

        System.out.println( ace +1);
}
}