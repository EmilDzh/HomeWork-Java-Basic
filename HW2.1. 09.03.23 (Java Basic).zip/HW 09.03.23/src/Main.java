public class Main {
    public static final char MONKEY = 'M';
    public static final char DOG = 'd';
    public static void main(String[] args) {

        byte son = 12;
        short son1 = 120;
        int son2 = 1234;
        long son3 = 12345556;
        float son4 = 10.2f;
        double son5 = 20.5;
        char son6 = MONKEY ;
        boolean son7isonsleep = true;
        System.out.println( son );
        System.out.println(son1);
        System.out.println(son2 );
        System.out.println(son3 );
        System.out.println(son4 );
        System.out.println(son5 );
        System.out.println(son6 );
        System.out.println(son7isonsleep );
        System.out.println();
        son2  = son2 + 10 ;
        System.out.println(son2);
        son4 = son4 * 2;
        System.out.println(son4);
        son5 = son5 / 2;
        System.out.println(son5);
    }
}