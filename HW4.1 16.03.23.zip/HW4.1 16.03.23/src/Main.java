public class Main {
    //1 Создайте переменную byte b = 1;
    //2 Присвойте её значение новым переменным типов short, int, long, double.
    //3 Выведите значение новых переменных в консоль
    public static void main(String[] args) {

        byte b = 1;
        short c = (short) b;
        int d = (int) c;
        long e = (long) d;
        double f = (double) e;
        System.out.println(f);

    }
}