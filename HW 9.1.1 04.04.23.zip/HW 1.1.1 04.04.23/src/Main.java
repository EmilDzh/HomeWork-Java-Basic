import java.util.Random;

public class Main {
    //TODO это второй проэкт (способ) первого задания.
    ////Проект 1. Используйте while:
    //    //Напиши программу, которая моделирует ситуацию.
    //    //Ты попросил друзей скинуться на подарок на твой День Рождения.
    //    // Каждый друг случайным образом может подарить тебе одну купюру номиналом 500, 1000, 2000 или 5000 рублей.
    //    // Твоя цель - новенький игровой ПК, который стоит 100 000 рублей.
    //    //Как только друзья подарят тебе нужную сумму (или даже чуть больше),
    //    // останавливай сбор подарков и веди всех выпить за твоё здоровье в лучший бар города!
    public static void main(String[] args) {

        Random rnd = new Random();

        int a = 0;
        int counter = 0;

        while (counter < 100000) {

            a = rnd.nextInt(0, 5100);

            if (a == 500) {
                System.out.println(a);
                counter = counter + a;
            }

            if(a == 1000) {
                System.out.println(a);
                counter = counter + a;
            }

            if(a == 2000) {
                System.out.println(a);
                counter = counter + a;
            }

            if(a ==5000) {
                System.out.println(a);
                counter = counter + a;
            }


        }
        System.out.println("Друзья уже собралось "+ counter + " ГО уже бухать))" );


    }
}