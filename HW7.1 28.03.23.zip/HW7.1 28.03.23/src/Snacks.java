public enum Snacks {
   TUC,SNIKERS,MARS,TWIX
}
