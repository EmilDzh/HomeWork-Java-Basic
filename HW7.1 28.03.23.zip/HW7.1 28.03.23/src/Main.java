import java.util.Scanner;

public class Main {
    //Проект 1. Перечисления
    //Создайте перечисление для угощений в снек-автомате (3-4 позиции).
    //Пользователь вводит номер снека. Программа должна вывести название снека, который выдал автомат.
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите номер");
        int SnacksNum = scn.nextInt() -1;
        String name = null;

        if (Snacks.TUC.ordinal() == SnacksNum){
            name = Snacks.TUC.name();

        } if (Snacks.SNIKERS.ordinal() == SnacksNum){
            name = Snacks.SNIKERS.name();

        } if (Snacks.MARS.ordinal() == SnacksNum){
            name = Snacks.MARS.name();

        } if (Snacks.TWIX.ordinal() == SnacksNum){
            name = Snacks.TWIX.name();

        }
        System.out.println("название снека:" + name);

    }
}