public class Main {
    public static void main(String[] args) {

        int i1 = 4;
        int i2 = 5;
        long l1 = 6;
        long l2 = 7;
        double d1 = 5.3;
        double d2 = 4.1;
        float f1 = 2.2f;
        float f2 = 3.4f;

        int  gg1 = i1 + i2;
        long gg2 = l1 + l2;
        long gg3 = i1 + l1;
        float gg4 = i1 + f1;
        double gg5 = i1 + d1;
        double gg6 = l1 + d1;
        System.out.println(gg1);
        System.out.println(gg2);
        System.out.println(gg3);
        System.out.println(gg4);
        System.out.println(gg5);
        System.out.println(gg6);
    }
}