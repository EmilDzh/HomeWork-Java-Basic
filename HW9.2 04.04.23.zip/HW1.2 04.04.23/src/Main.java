import java.util.Scanner;

public class Main {
    //Проект 2. Используйте for.
    //Необходимо суммировать все нечётные целые числа в диапазоне,
    // введённом пользователем. Пользователь указывает нижнюю и верхнюю границу диапазона.
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Укажите диапазон");
        int a = scn.nextInt();
        int b = scn.nextInt();
        int c = 0;
        for (; a < b; a++) {
            if(a%2!=0){
                c = c+a;

                System.out.println(c);
            }


        }


    }
}