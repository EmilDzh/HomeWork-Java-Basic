import java.util.Random;
import java.util.Scanner;

public class Main {
    //    // 1 уровень сложности: Напишите аналог Random для генерации строк - StringRandom.
    //    // В классе реализуйте набор публичных статических методов: первый метод генерирует слово заданной длины,
    //    // состоящее из  английских букв (любой набор букв).
    //    Второй метод генерирует предложение из заданного количества разных слов.
    //    // Третий метод генерирует текст из заданного количества разных предложений,
    //    // разделяя предложения случайными знаками препинания из набора (. или ! или ? или …).
    //    // В методе main сгенерируйте текст из 1000 предложений.
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("задайте длину");
        int wordl = scn.nextInt();
        String ALPHABET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        Random rnd = new Random();
        int a = rnd.nextInt(0,ALPHABET.length());
        System.out.println(generateWord(ALPHABET,wordl) + " 1 метод" + " " + "слово заданной длины ");
        System.out.println(generateText(ALPHABET,wordl) + " 2 метод" + " количество слов");
        System.out.println(generateTexts(ALPHABET,wordl));

    }
    public static  String generateWord(String b , int wordLength){
        Random rand = new Random();
        String word = "";
        for (int i = 0; i < wordLength; i++) {
            int rndNum = rand.nextInt(0,b.length());
            word = word + b.charAt(rndNum);

        }return word;
    }

    public static String generateText(String c, int textLength ){
        Random ran = new Random();
        String text = "";
        for (int i = 0; i < textLength; i++) {
            String worda = "";
            for (int j = 0; j < ran.nextInt(2,8); j++) {
                int ranNum = ran.nextInt(0,c.length());
                worda = worda + c.charAt(ranNum);

            }
            text = text + " " + worda;
        } return text;

    }

    public static String generateTexts (String d , int textLength){
        char[] punctuation = {'.', '!', '?', '…'};
        Random r = new Random();
        String text = "";
        for (int i = 0; i < textLength; i++) {
            String words = "";
            for (int j = 0; j < r.nextInt(5,15); j++) {
                String word = generateWord(d,r.nextInt(0,10));
                words = words + " " + word;
            }
            text = text + words + punctuation[r.nextInt(0,punctuation.length)];

        } return text;


    }



}