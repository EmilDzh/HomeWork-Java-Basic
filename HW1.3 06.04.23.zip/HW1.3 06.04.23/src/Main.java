import java.util.Arrays;
import java.util.Scanner;

public class Main {

    //3 Пользователь вводит строку. Разместите буквы в строке по алфавиту и выведите в консоль
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        String a = scn.nextLine();
        char[] arr = a.toCharArray();

            Arrays.sort(arr);
            System.out.println(Arrays.toString(arr));
            
       





    }
}