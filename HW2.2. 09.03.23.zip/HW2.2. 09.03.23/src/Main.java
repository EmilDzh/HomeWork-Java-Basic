public class Main {
    public static void main(String[] args) {

        int son = 250;
        int son1 = 300;
        System.out.println(son + son1);
        int summe = 350;
        System.out.println();
        System.out.println( son * son1 );
        int summe1 = 75000;
        System.out.println();
        System.out.println( son1 % son );
        int summe2 = 50
    }
}