import java.util.Arrays;

public class Main {
    // 1 уровень сложности: Проект 1. Двумерные массивы
    //1 Создайте двумерный массив и заполните его буквами русского алфавита.
    //2* (по желанию) Пусть в двумерном массиве N элементов.
    // Заполните двумерный массив целыми числами от 1 до N по спирали. Например,
    //01 02 03 04
    //12 13 14 05
    //11 16 15 06
    //10 09 08 07
    public static void main(String[] args) {

        char[][] abc = new char[5][7];
        char init = 'А';
        char last = 'Я';

        for (int i = 0; i < abc.length; i++) {
            for (int j = 0; j < abc[i].length; j++) {
                abc[i][j] = init;
                init++;
                if (init > last) {
                    break;
                }


            }

        }
        System.out.println(Arrays.deepToString(abc));

        int[][] array = new int[5][5];
        int num = 1;
        int max = 5 * 5;
        int rmin = 0;//rows строки
        int cmin = 0;// columns столбцы
        int rmax = 5 - 1;
        int cmax = 5 - 1;

        while (num <= max) {
            //путь верхний строки  справа  налево
            for (int i = cmin; i <= cmax && num <= max; i++) {
                array[rmin][i] = num++;
            }
            rmin++;
            //путь в низ по правому краю
            for (int i = rmin; i <= rmax && num <= max; i++) {
                array[i][cmax] = num++;
            }
            cmax--;// уменьшаем длины строки в каждой итерации
            //путь нижний строки
            for (int i = cmax; i >= cmin && num <= max; i--) {
                array[rmax][i] = num++;
            }
            rmax--;
            //путь  вверх по левому краю
            for (int i = rmax; i >= rmin && num <= max; i--) {
                array[i][cmin] = num++;
            }
            cmin++;
        }


        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++)
                System.out.print(array[i][j] + "\t");
            System.out.println();


        }
    }


}


















