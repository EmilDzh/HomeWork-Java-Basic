import java.util.Random;

public class Main {
    //4 С помощью Random сгенерируйте три числа.
    // Напишите программу, которая находит максимальное из них. Используйте тернарные операторы.
    public static void main(String[] args) {

        Random ran = new Random();

        int a = ran.nextInt();
        int b = ran.nextInt();
        int c = ran.nextInt();
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);

        int d = Math.max(a, b);
        int f = Math.max(d, c);

        System.out.println(f);



    }
}